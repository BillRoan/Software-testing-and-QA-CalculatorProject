package org.example.calculator;

import org.example.calculator.service.CalculatorService;
import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

class CalculatorServiceTest {

    private final CalculatorService service = new CalculatorService();

    @Test
    void computeMean_ValidInput_ReturnsCorrectMean() {
        double result = service.computeMean(Arrays.asList(10.0, 20.0, 30.0));
        assertEquals(20.0, result);
    }

    @Test
    void computeSampleStdDev_ValidInput_ReturnsCorrectValue() {
        double result = service.computeSampleStandardDeviation(Arrays.asList(2.0, 4.0, 6.0, 8.0));
        assertEquals(2.58, result, 0.01);
    }
}
