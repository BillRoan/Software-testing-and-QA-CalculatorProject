package org.example.calculator;

import com.microsoft.playwright.*;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class CalculatorE2ETest {

    @Test
    void calculateMean_ShowsCorrectResult() {
        try (Playwright playwright = Playwright.create()) {
            Browser browser = playwright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(true));
            Page page = browser.newPage();

            // Navigate to the application
            page.navigate("http://localhost:8080");

            // Fill the input values and click the button
            page.fill("textarea#values", "10\n20\n30");
            page.click("button");

            // Wait for the result to appear
            Locator resultLocator = page.locator("div#result");
            resultLocator.waitFor(new Locator.WaitForOptions().setTimeout(60000)); // Wait up to 60 seconds

            // Get and assert the result
            String result = resultLocator.textContent();
            assertTrue(result.contains("Result: 20.0"), "Expected result to contain 'Result: 20.0' but got: " + result);
        }
    }
}


