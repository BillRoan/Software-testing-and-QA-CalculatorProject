package org.example.calculator.model;

public class CalculationResult {
    private double result;
    private boolean success;
    private String operation;
    private String errorMessage;

    public CalculationResult() {
    }

    public CalculationResult(double result, boolean success, String operation, String errorMessage) {
        this.result = result;
        this.success = success;
        this.operation = operation;
        this.errorMessage = errorMessage;
    }

    public double getResult() {
        return result;
    }

    public void setResult(double result) {
        this.result = result;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }
}
