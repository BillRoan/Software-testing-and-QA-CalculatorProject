package org.example.calculator.controller;

import org.example.calculator.service.CalculatorService;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class CalculatorController {

    private final CalculatorService calculatorService;

    public CalculatorController(CalculatorService calculatorService) {
        this.calculatorService = calculatorService;
    }

    /**
     * Serve the main HTML page.
     */
    @GetMapping("/")
    public String home() {
        return "index"; // Maps to src/main/resources/templates/index.html
    }

    /**
     * API Endpoint: Compute Mean
     */
    @PostMapping("/api/calculator/mean")
    @ResponseBody
    public ResponseEntity<Double> computeMean(@RequestBody List<Double> values) {
        return ResponseEntity.ok(calculatorService.computeMean(values));
    }

    /**
     * API Endpoint: Compute Sample Standard Deviation
     */
    @PostMapping("/api/calculator/sample-std-dev")
    @ResponseBody
    public ResponseEntity<Double> computeSampleStdDev(@RequestBody List<Double> values) {
        return ResponseEntity.ok(calculatorService.computeSampleStandardDeviation(values));
    }

    /**
     * API Endpoint: Compute Population Standard Deviation
     */
    @PostMapping("/api/calculator/population-std-dev")
    @ResponseBody
    public ResponseEntity<Double> computePopulationStdDev(@RequestBody List<Double> values) {
        return ResponseEntity.ok(calculatorService.computePopulationStandardDeviation(values));
    }

    /**
     * API Endpoint: Compute Z Score
     */
    @PostMapping("/api/calculator/z-score")
    @ResponseBody
    public ResponseEntity<Double> computeZScore(
            @RequestParam double value,
            @RequestParam double mean,
            @RequestParam double stdDev) {
        return ResponseEntity.ok(calculatorService.computeZScore(value, mean, stdDev));
    }
}
