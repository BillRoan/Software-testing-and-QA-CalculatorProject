package org.example.calculator.service;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CalculatorService {
    public double computeMean(List<Double> values) {
        return values.stream().mapToDouble(Double::doubleValue).average().orElse(0.0);
    }

    public double computeSampleStandardDeviation(List<Double> values) {
        double mean = computeMean(values);
        double variance = values.stream().mapToDouble(v -> Math.pow(v - mean, 2)).sum() / (values.size() - 1);
        return Math.sqrt(variance);
    }

    public double computePopulationStandardDeviation(List<Double> values) {
        double mean = computeMean(values);
        double variance = values.stream().mapToDouble(v -> Math.pow(v - mean, 2)).sum() / values.size();
        return Math.sqrt(variance);
    }

    public double computeZScore(double value, double mean, double stdDev) {
        return (value - mean) / stdDev;
    }
}
